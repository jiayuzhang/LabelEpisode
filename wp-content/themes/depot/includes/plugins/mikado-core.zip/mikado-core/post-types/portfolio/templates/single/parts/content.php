<div class="mkd-ps-info-item mkd-ps-content-item">
    <h2 class="mkd-portfolio-item-title"><?php the_title(); ?></h2>
    <?php the_content(); ?>
</div>