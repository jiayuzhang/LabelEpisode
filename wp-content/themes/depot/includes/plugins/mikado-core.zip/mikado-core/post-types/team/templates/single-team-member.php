<?php

get_header();

depot_mikado_get_title();

mkd_core_get_single_team();

get_footer();