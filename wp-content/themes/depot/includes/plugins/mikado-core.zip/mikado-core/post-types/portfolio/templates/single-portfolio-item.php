<?php

get_header();

depot_mikado_get_title(false, 'portfolio_single');

mkd_core_get_single_portfolio();

get_footer();