<div class="mkd-mobile-slider-holder">
    <div class="mkd-ms-inner mkd-owl-slider" <?php echo depot_mikado_get_inline_attrs($slider_data); ?>>
        <?php echo do_shortcode($content); ?>
    </div>
</div>