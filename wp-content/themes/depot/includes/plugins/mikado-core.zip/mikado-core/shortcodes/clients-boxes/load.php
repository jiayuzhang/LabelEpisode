<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/clients-boxes/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/clients-boxes/clients-boxes.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/clients-boxes/clients-boxes-item.php';
