<div class="mkd-clients-boxes-holder <?php echo esc_attr($holder_classes); ?>">
	<div class="mkd-cb-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>