<?php

include_once MIKADO_MEMBERSHIP_SHORTCODES_PATH.'/register/functions.php';
include_once MIKADO_MEMBERSHIP_SHORTCODES_PATH.'/register/register.php';