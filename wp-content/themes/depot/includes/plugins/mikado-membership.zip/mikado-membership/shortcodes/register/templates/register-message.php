<div class="mkd-register-notice">
	<h5><?php echo esc_html($message); ?></h5>
	<a href="#" class="mkd-login-action-btn" data-el="#mkd-login-content" data-title="<?php esc_html_e('LOGIN', 'mkd_membership'); ?>"><?php esc_html_e('LOGIN', 'mkd_membership'); ?></a>
</div>